#pragma once
class EventClass
{
public:
	EventClass();
	~EventClass();
};

