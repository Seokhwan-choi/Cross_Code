//#pragma once
//#include "GameObject.h"
//class TileManager : public GameObject
//{
//private:
//	vector<class Tile*> TilePool;
//public:
//
//	virtual void Init() override;
//	virtual void Release() override;
//	virtual void Update() override;
//	virtual void Render() override;
//
//	void AddTile(class Tile* tile) { TilePool.push_back(tile); }
//
//	TileManager() {}
//	~TileManager() {}
//};
//
