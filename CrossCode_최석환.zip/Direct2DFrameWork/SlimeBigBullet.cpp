#include "stdafx.h"
#include "SlimeBigBullet.h"


SlimeBigBullet::SlimeBigBullet()
{

}


SlimeBigBullet::~SlimeBigBullet()
{

}
