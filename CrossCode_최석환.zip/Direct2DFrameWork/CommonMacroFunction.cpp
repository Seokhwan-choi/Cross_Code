#include "stdafx.h"
#include "CommonMacroFunction.h"