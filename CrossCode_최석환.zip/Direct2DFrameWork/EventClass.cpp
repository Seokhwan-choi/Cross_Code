#include "stdafx.h"
#include "EventClass.h"


EventClass::EventClass()
{
}


EventClass::~EventClass()
{
}
