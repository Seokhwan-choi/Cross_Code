#include "stdafx.h"
//#include "TileManager.h"
//
//void TileManager::Init()
//{
//}
//
//void TileManager::Release()
//{
//
//}
//
//void TileManager::Update()
//{
//
//}
//
//void TileManager::Render()
//{
//
//}